package td3;

public interface ExpressionArithmetique {
	public ExpressionArithmetique simplifier();
	public double calculer()   ;
	
	public String afficher();
	
}